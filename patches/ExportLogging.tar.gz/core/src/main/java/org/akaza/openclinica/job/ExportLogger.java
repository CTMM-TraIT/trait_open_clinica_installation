package org.akaza.openclinica.job;

import org.akaza.openclinica.bean.extract.DatasetBean;
import org.akaza.openclinica.bean.login.UserAccountBean;
import org.akaza.openclinica.bean.managestudy.StudyBean;
import org.akaza.openclinica.bean.submit.ItemBean;
import org.akaza.openclinica.dao.extract.DatasetDAO;
import org.akaza.openclinica.dao.submit.ItemDAO;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Specialist class to log all privacy related information which is exported with an OpenClinica export.
 * Created by Jacob Rousseau on 16-Mar-2015.
 * Copyright CTMM-TraIT / VUmc (c) 2015
 */
public class ExportLogger {

    private static final Logger logger = LoggerFactory.getLogger(ExportLogger.class);

    /**
     * Default constructor
     */
    public ExportLogger() {

    }

    /**
     * Logs (on info level) the user name and the names of the fields in an export.
     * @param currentStudy the study being exported
     * @param user the user performing the export
     * @param datasetBean the dataset definition used for the export
     * @param itemDAO an item DAO object used to retrieve items from the data-base
     * @param fileDescription the type of the export as defined in the file <code>extract.properties</code>
     * @param notificationEmail the addresses of recipients to whom the notification email is sent
     *
     */
    public void logExport(StudyBean currentStudy, UserAccountBean user, DatasetBean datasetBean, ItemDAO itemDAO, String fileDescription, String notificationEmail) {
        String studyInformation = "'" + currentStudy.getName() + "'";

        logger.info(user.getName() + " performed export '" + datasetBean.getName() +  "' for study " + studyInformation + "; format: " + fileDescription);
        logger.info("Mail notification to: " + notificationEmail);
        DatasetDAO datasetDAO = new DatasetDAO(null);
        String sql = datasetBean.getSQLStatement();
        String itemIDStr = datasetDAO.parseSQLDataset(sql, false, true);
        logger.info("Item IDs of fields exported: " + itemIDStr);
        String nameStr = "Item names: ";
        itemIDStr = StringUtils.remove(itemIDStr, '(');
        itemIDStr = StringUtils.remove(itemIDStr, ')');
        String[] itemIDStringList = StringUtils.split(itemIDStr, ',');

        for (String itemID : itemIDStringList) {
            Integer itemIDInt = Integer.valueOf(itemID);
            ItemBean item = (ItemBean) itemDAO.findByPK(itemIDInt);
            nameStr = nameStr + item.getName() + ", ";
        }
        nameStr = StringUtils.removeEnd(nameStr,", ");
        logger.info(nameStr);
    }
}
